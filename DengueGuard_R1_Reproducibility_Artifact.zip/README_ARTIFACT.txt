DengueGuard IJIES Major Revision Artifact
Paper ID: 20267240
Seeds: [11, 22, 33]
Horizons: [1, 2, 4, 8, 12]
Device: cpu

Interpretation constraints:
- Internal two-city retrospective benchmark only.
- Equality counts as outbreak (cases >= training-derived threshold).
- 75th percentile uses linear interpolation.
- Retrospective environmental covariates do not encode real-time publication/revision latency.
- Moving-block bootstrap is the dependence-aware primary paired uncertainty analysis.
