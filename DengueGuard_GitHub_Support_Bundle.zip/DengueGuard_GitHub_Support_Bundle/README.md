# DengueGuard — Major Revision Reproducibility and Supporting Materials

This folder contains the supporting material assembled for the major revision of:

**DengueGuard: Reliability-Aware Multi-Horizon Dengue Forecasting with Gated Temporal Learning and Conformal Uncertainty Quantification**

The revision evaluates weekly dengue forecasting for San Juan and Iquitos at 1-, 2-, 4-, 8-, and 12-week horizons. The supporting files document the matched ablation/baseline analysis, dependence-aware statistical analysis, probabilistic and interval-reliability evaluation, reporting-delay sensitivity, supplementary feature/split information, and the point-by-point reviewer response.

## Repository organization

- `manuscript/`
  - corrected major-revision manuscript
  - point-by-point reviewer response
  - supplementary material
- `figures/`
  - matched-ablation MAE figure
  - reporting-delay sensitivity figures
  - canonical matched-baseline and moving-block-bootstrap figures
- `tables/`
  - reporting-delay sensitivity data
- `audit/`
  - finalization checklist
- `reproducibility/`
  - corrected revision package
  - note describing the Colab-generated reproducibility archive and rolling-origin CSV that must be copied from the original experiment run
- `SHA256SUMS.txt`
  - SHA-256 checksums for files in this support bundle

## Canonical interpretation used in the revision

The revised headline comparison uses the matched experiment set consistently. The principal conclusion is horizon-dependent model value rather than universal architectural superiority. Persistence remains difficult to beat at short horizons, while learned temporal models become more competitive at longer horizons. Ablation results show that the variable gate does not provide a uniform point-accuracy advantage, whereas the negative-binomial formulation has substantially stronger probabilistic support than the Poisson-head alternative. Interval reliability remains heterogeneous across cities.

## Important reproducibility files from the completed Colab run

Before creating the final immutable release, copy the original versions of the following files from the completed Colab experiment output into this repository:

1. `DengueGuard_IJIES_R1_Reproducibility_Artifact.zip`
   - expected SHA-256: `2913c0c924f0e6d2bdb0fee2276982ef459a825fcd35a4f50f0d3a4b63d99e3a`
2. `R2_temporal_replication_city_MAE.csv`
   - use the original generated CSV; do not reconstruct it from a truncated notebook display.

The reproducibility archive should contain, at minimum, split indices, preprocessing statistics, prediction files, calibration outputs, matched-ablation/baseline metrics, moving-block bootstrap outputs, probabilistic scores, outbreak-reliability metrics, feature manifest, reporting-delay sensitivity, and temporal-replication outputs.

## Data source

The analysis uses the public DengAI labelled training series for San Juan, Puerto Rico, and Iquitos, Peru. Competition test labels are not used for the reported internal chronological evaluation.

## Integrity

Use `SHA256SUMS.txt` to verify the files in this bundle. For journal resubmission, create a tagged GitHub release after the complete reproducibility archive and temporal-replication CSV have been added, and cite the immutable release URL or DOI in the manuscript.
