# Reproducibility artifacts

The reviewer-response experiment run generated an archive named:

`DengueGuard_IJIES_R1_Reproducibility_Artifact.zip`

Expected SHA-256 from the completed Colab run:

`2913c0c924f0e6d2bdb0fee2276982ef459a825fcd35a4f50f0d3a4b63d99e3a`

That Colab-generated ZIP was not available in the current ChatGPT working container when this GitHub upload bundle was assembled, so it is intentionally not duplicated here. Add the original archive from the Colab session before creating the final immutable GitHub release.

The same applies to the complete rolling-origin output `R2_temporal_replication_city_MAE.csv`; add the original CSV from the completed Colab run rather than reconstructing it from truncated notebook display output.
